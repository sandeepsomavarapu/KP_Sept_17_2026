import pyodbc
import pymysql


conn = pymysql.connect(
    host="localhost",
    user="root",
    password="rpsconsulting",
    database="bankdb",
    port=3306
)

print("Connection successful:", conn)
# conn=pyodbc.connect(conn_str)
# print(conn)
cursor=conn.cursor()
cursor.execute("select * from account")
print(cursor.fetchall())

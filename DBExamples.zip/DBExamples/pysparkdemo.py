import os
import sys


os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, sum

# 1. Initialize SparkSession (The entry point to PySpark)
spark = SparkSession.builder \
    .appName("PySpark Training for Freshers") \
    .getOrCreate()

# Sample Employee Data
data = [
    (1, "Alice", "Engineering", 85000, "NY"),
    (2, "Bob", "HR", 60000, "CA"),
    (3, "Charlie", "Engineering", 90000, "NY"),
    (4, "David", "HR", 65000, "CA"),
    (5, "Eve", "Finance", 75000, "NY"),
    (6, "Frank", "Engineering", 110000, "CA")
]

schema = ["id", "name", "department", "salary", "state"]

# 2. Create DataFrame
df = spark.createDataFrame(data, schema=schema)

# Action: Displays the top 20 rows
df.show()

# Print Schema (Data types of columns)
df.printSchema()
import sqlite3

#1.connect
conn=sqlite3.connect("company.db")
cursor=conn.cursor()

# cursor.execute("""
# create table employees(
# id Integer primary key AUTOINCREMENT,
# name text not null,
# department text not null,
# salary not null)
# """)

cursor.execute("insert into employees(name,department,salary) values(?,?,?)",("suresh","Hr",87000))
conn.commit()

cursor.execute("select * from employees where department=?",("Hr",))
print("Data :",cursor.fetchall())

conn.close()
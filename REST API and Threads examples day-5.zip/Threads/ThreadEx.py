from threading import *
def display():
    for i in range(1,11):
        print("child thread")
thread=Thread(target=display)   
thread.start()  
for i in range(1,11):
    print("Main Thread")   

#Thread shedular --    
from threading import *
class MyThread(Thread):
    def run(self):
        for i in range(10):
            print("Child Thread")
thread=MyThread()
thread.start()
for i in range(10):
    print("main thread")

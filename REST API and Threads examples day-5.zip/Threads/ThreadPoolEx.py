from concurrent.futures import ThreadPoolExecutor

def task(number):
    return number* number

with ThreadPoolExecutor(max_workers=3) as executor:
    results=executor.map(task,[1,2,3,4,5])
    print(list(results))

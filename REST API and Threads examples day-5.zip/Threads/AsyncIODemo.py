import asyncio

async def greet():
    print("hello....")
    await asyncio.sleep(2)
    print("welcome.... ")
asyncio.run(greet())

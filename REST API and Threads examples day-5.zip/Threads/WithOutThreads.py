import time

def task(name):
    print(name)
    time.sleep(10)
start=time.time()
task("Task1")
task("Task2")

print("Time: ",time.time()-start)
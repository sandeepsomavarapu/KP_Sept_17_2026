import asyncio

async def task(name):
    print(name,"started")
    await asyncio.sleep(2)
    print(name,"completed")
async def main():
    await task("TASK1")
    await task("TASK2")

asyncio.run(main())        
from threading import * 
import time

def task(name):
    print(name,"started")
    time.sleep(2)
    print(name,"completed")
start=time.time()   
t1=Thread(target=task,args=("Task1",))
t2=Thread(target=task,args=("Task2",))
t1.start()
t2.start()

t1.join()
t2.join()
print("Time: ",time.time()-start)
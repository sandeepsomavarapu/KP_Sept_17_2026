from threading import *
class Test:
    def display(self):
        for i in range(10):
            print("child thread")
obj=Test()
thread=Thread(target=obj.display)
thread.start()
for i in range(10):
    print("Main Thread")
                
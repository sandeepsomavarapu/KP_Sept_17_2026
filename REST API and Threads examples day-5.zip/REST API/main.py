from fastapi import FastAPI

app=FastAPI()

@app.get("/")
def home():
    return {
        "message":"Hello welcome to app"
    }
@app.get("/user")
def get_users():
    return {
        "message":"usersinfo"
    }
import json

user={
    "id":123,
    "name":"suresh",
    "active":True
}
json_data=json.dumps(user)
print(json_data)
print(type(json_data))
user=json.loads(json_data)
print(user)
print(type(user))
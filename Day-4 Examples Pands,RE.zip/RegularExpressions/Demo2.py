import re

matcher=re.finditer("ab","abaababa")
count=0
for match in matcher:
    count+=1
    print(match.start(),"..",match.end(),"..",match.group())
print("the no of occurances :",count)    
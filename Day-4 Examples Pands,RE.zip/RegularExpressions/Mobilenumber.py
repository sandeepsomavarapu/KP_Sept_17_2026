import re
contact=input("Enter your contact number")
m=re.fullmatch("[7-9][0-9]{9}",contact)
if m!=None:
    print("valid indian contact number")
else:
    print("Invalid indian contact number")    
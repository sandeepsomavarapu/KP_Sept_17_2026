import re

matcher=re.finditer("a{2,4}","abaaabaaab")
for match in matcher:
    print(match.start(),"..",match.group())
  
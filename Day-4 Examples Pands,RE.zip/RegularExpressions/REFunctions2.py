#start,end,compile,finditer,group
#match-->to check the pattern is beginning of the string or not 
import re
s=input("Enter pattern to check")
m=re.search(s,"abaaabababaaa")
if m!=None:
    print("Matching is available")
    print(m.start(),"...",m.end())
else:
    print("matching not available")


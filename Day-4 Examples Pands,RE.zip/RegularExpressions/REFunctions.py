#start,end,compile,finditer,group
#match-->to check the pattern is beginning of the string or not 
import re
s=input("Enter pattern to check")
m=re.match(s,"abcdefgh")
if m!=None:
    print("matching is found at the beginning of the string ")
    print(m.start()," .. ",m.end())
else:
    print("matching not found")


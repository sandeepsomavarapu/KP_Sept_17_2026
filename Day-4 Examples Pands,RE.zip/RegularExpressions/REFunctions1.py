#start,end,compile,finditer,group
#match-->to check the pattern is beginning of the string or not 
import re
s=input("Enter pattern to check")
m=re.fullmatch(s,"abcdefgh")
if m!=None:
    print("full string matched")
else:
    print("full string not matched")


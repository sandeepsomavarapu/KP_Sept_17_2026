import re

list=re.findall("[0-9]","a7b9c5kz")

print(list)

result=re.sub("[a-z]","*","a7b9c5kz")
print(result)


message="Learning Python is easy"
response=re.search("easy$",message)
if response!=None:
    print("the target string started with Learning") 
else :
    print("the target string not started/ending with Learning")    
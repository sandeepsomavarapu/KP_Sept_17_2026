import pandas as pd

df=pd.read_csv('data.csv')
print(df)
print(df.head(1))
print(df.tail(2))

print(df.info())
# updated_df=df.dropna(inplace=True)
# print(updated_df.info())
# print(df)x
df.fillna({'Calories':130},inplace=True)
print(df)
print(df.info())
print(df.mean())
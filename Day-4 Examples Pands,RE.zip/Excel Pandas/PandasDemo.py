#pip install pandas
#data sets   -->analyze,cleaning,exploring,manupulating
#pandas-->panel data and  python data analysis mckinney 2008
import pandas as pd

mydataset={
"students":['suresh','naresh','ramesh'],
"marks":[230,440,650]
}
mydf=pd.DataFrame(mydataset)
print(mydf)

print(type(mydf))
print(pd.__version__)


marks=[23,332,34,45]

mymarks=pd.Series(marks)
print(mymarks)
print(type(mymarks))
print(mymarks[0])

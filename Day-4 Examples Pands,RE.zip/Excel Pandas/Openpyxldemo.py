#pip install openpyxl
from openpyxl import Workbook

# Create a new workbook and select active sheet
wb = Workbook()
ws = wb.active
ws.title = "Sales Report"

# Write data to specific cells
ws['A1'] = "Item"
ws['B1'] = "Amount"

ws['A2'] = "Widget A"
ws['B2'] = 1500

ws['A3'] = "Widget B"
ws['B3'] = 2300

# Add an Excel formula
ws['A4'] = "Total"
ws['B4'] = "=SUM(B2:B3)"

# Save the workbook
wb.save("sales_report.xlsx")
print("Workbook saved!")

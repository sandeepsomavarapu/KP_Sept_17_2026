import pandas as pd
mydataset={
"students":['suresh','naresh','ramesh'],
"marks":[230,440,650]
}
mydf=pd.DataFrame(mydataset)
print(mydf)
print(mydf.loc[0])
print(mydf.loc[[0,1]])

df=pd.read_csv("data.csv")
print(df)
print(df.to_string())




# df1=pd.read_excel('sales_report.xlsx')
# print(df1)